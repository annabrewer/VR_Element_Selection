# Thank You Credits

A big thank you to the supporters of VRTK via the VRTK Patreon page at https://www.patreon.com/vrtk

### Sponsors

[![image](https://user-images.githubusercontent.com/1029673/27898738-28f0e226-621f-11e7-9fdb-8618d85ba372.png)](https://www.realestate.com.au) [![image](https://user-images.githubusercontent.com/1029673/29113652-8fa11ca4-7ce9-11e7-9e33-88308af369b9.png)](http://alvios.com/)

### Name List

 * **realestate.co.au - Luke Chadwick** *[Professional Sponsor]*
 * **Alvios Game Studio - Blueteak** *[Sponsor]*
 * Tuukka Takala
 * BinaryLegend
 * Mark Bradley
 * TreeFortress Games
 * Matt Ostgard
 * Adam Salmi
 * Mcdoogleh
 * cognitiveVR
 * Kent Bowling
 * Alex Vainberg
 * VR Game Development Mini-Degree by Zenva
 * Michael Angel
 * adam awesomeface
 * Don MacSween
 * Tim Foster
 * Chris Tuminello
 * mori
 * Tim Lobes
 * Bartek Tułodziecki
 * Chris Ross
 * Grayson Deitering
 * Michal VRoblewski
 * braden
 * Ian McNab
 * Joe Ferguson
 * Balazs Faludi
 * Andy Baker
 * Joey Parr
 * Kyle Mausser
 * Niklas Dennerståhl
 * Michael Hurley
 * Roland
 * Steve Weintraut
 * Thomas Kildren
 * Jarrell Norwood
 * Tanner Ochel
 * Will Lingard
 * TigerLily
 * Stephen Elkins
 * Adam Tannir
 * Casual Immersions Entertainment
 * Jonathan Linowes
 * Matthew Boynton
 * Agatha Yu
 * David
 * Hgulgen
 * Luke Pierson
 * Eric Vander Wal
 * Juho Salonen
 * Jedrzej Jonasz
 * Ben McNelly
 * Devon Grandahl
 * ManBearPig
 * Kenneth Lemieux
 * Trevor Gibbons
 * Stephen Eisenhauer